// src/components/common/Header.jsx
import React, { useState } from 'react';
import { Link as RouterLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext'; // Import useAuth

// MUI Components
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import Link from '@mui/material/Link'; // MUI Link
import IconButton from '@mui/material/IconButton';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import Tooltip from '@mui/material/Tooltip'; // Thêm Tooltip cho icon
import Chip from '@mui/material/Chip'; // Thêm Chip để hiển thị vai trò
import BusinessCenterIcon from '@mui/icons-material/BusinessCenter'; // Icon cho chip vai trò

// Icons
import AccountCircle from '@mui/icons-material/AccountCircle';
import LogoutIcon from '@mui/icons-material/Logout';
import DashboardIcon from '@mui/icons-material/Dashboard';
import SettingsIcon from '@mui/icons-material/Settings';
import PostAddIcon from '@mui/icons-material/PostAdd';
import WorkHistoryIcon from '@mui/icons-material/WorkHistory'; // Icon cho ứng viên
import ManageAccountsIcon from '@mui/icons-material/ManageAccounts'; // Icon cho NTD
import PeopleIcon from '@mui/icons-material/People'; // Icon cho NTD


function Header() {
  const navigate = useNavigate();
  const { authState, logout } = useAuth(); //
  const { isAuthenticated, user } = authState; //
  const userRole = user?.role; // Lấy vai trò người dùng

  // State cho User Menu
  const [anchorElUser, setAnchorElUser] = useState(null);

  const handleOpenUserMenu = (event) => {
    setAnchorElUser(event.currentTarget);
  };

  const handleCloseUserMenu = () => {
    setAnchorElUser(null);
  };

  const handleLogout = () => {
    logout(); // Gọi hàm logout từ context
    handleCloseUserMenu(); // Đóng menu
    navigate('/'); // Về trang chủ
  };

  // Điều hướng dựa trên vai trò
  const handleNavigate = (path) => {
      navigate(path);
      handleCloseUserMenu();
  }

  // Xác định các đường dẫn dựa trên vai trò
  const dashboardPath = userRole === 'employer' ? '/employer/dashboard' : '/candidate/dashboard';
  const settingsPath = userRole === 'employer' ? '/employer/settings' : '/candidate/settings';
  const profilePath = userRole === 'employer' ? '/employer/company-profile' : '/candidate/profile';

  return (
    <AppBar position="sticky" elevation={1} sx={{ bgcolor: 'background.paper', color: 'text.primary' }}>
      <Toolbar sx={{ justifyContent: 'space-between' }}>

        {/* Logo và Navigation Links Chung */}
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <Typography variant="h6" component="div" sx={{ mr: 3 }}>
            <Link component={RouterLink} to="/" color="inherit" sx={{ textDecoration: 'none', fontWeight: 'bold' }}>
              TalentHub
            </Link>
          </Typography>

          {/* === Navigation Links THEO VAI TRÒ === */}
          <Box sx={{ display: { xs: 'none', md: 'flex' }, gap: 2 }}>
            {/* Links cho mọi người (chưa đăng nhập hoặc candidate) */}
            {(!isAuthenticated || userRole === 'candidate') && (
                <>
                    <Button color="inherit" component={RouterLink} to="/jobs">
                        Tìm việc làm
                    </Button>
                    <Button color="inherit" component={RouterLink} to="/companies">
                        Công ty
                    </Button>
                    {/* Candidate có thể thêm link nhanh ở đây nếu muốn */}
                    {/* {userRole === 'candidate' && (
                        <Button color="inherit" component={RouterLink} to="/candidate/applications">
                            Việc đã ứng tuyển
                        </Button>
                    )} */}
                </>
            )}

             {/* Links cho Nhà tuyển dụng */}
             {userRole === 'employer' && (
                 <>
                    <Button color="inherit" component={RouterLink} to="/employer/manage-jobs">
                        Quản lý tin đăng
                    </Button>
                     <Button color="inherit" component={RouterLink} to="/employer/applicants"> {/* Link tới trang quản lý ứng viên tổng */}
                        Quản lý ứng viên
                    </Button>
                 </>
             )}
          </Box>
          {/* === KẾT THÚC NAV LINKS THEO VAI TRÒ === */}

        </Box>

        {/* Actions: Post Job, Auth Buttons / User Menu */}
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          {/* === Nút Đăng tin (Chỉ hiển thị cho Employer hoặc chưa đăng nhập) === */}
          {(!isAuthenticated || userRole === 'employer') && (
              <Button
                variant="contained"
                color="primary"
                startIcon={<PostAddIcon />}
                component={RouterLink}
                // Nếu chưa đăng nhập, khi bấm sẽ yêu cầu đăng nhập trước khi tới trang đăng tin
                // Nếu là employer, link thẳng tới trang đăng tin
                to={isAuthenticated ? "/employer/post-job" : "/login?redirect=/employer/post-job"}
                sx={{ display: { xs: 'none', sm: 'inline-flex' } }}
              >
                {userRole === 'employer' ? 'Đăng tin' : 'Nhà tuyển dụng Đăng tin'}
              </Button>
          )}
           {/* === KẾT THÚC NÚT ĐĂNG TIN === */}


          {/* Auth Buttons / User Menu */}
          {isAuthenticated ? (
            <>
              {/* === THÊM CHIP HIỂN THỊ VAI TRÒ === */}
              {userRole && (
                <Chip
                icon={userRole === 'employer' ? <BusinessCenterIcon fontSize="small" /> : <AccountCircle fontSize="small" />}
                label={userRole === 'employer' ? 'Nhà tuyển dụng' : 'Ứng viên'}
                // Chọn màu phù hợp
                color={userRole === 'employer' ? 'info' : 'success'}
                size="small"
                sx={{ display: { xs: 'none', md: 'inline-flex' }, mr: 1 }} // Chỉ hiện trên màn hình lớn, thêm margin
                />
            )}
      {/* === KẾT THÚC THÊM CHIP === */}
              {/* User Menu như cũ */}
              <Tooltip title="Tài khoản">
                <IconButton onClick={handleOpenUserMenu} sx={{ p: 0 }}>
                   <AccountCircle sx={{ color: 'action.active' }} />
                </IconButton>
              </Tooltip>
              <Menu
                sx={{ mt: '45px' }}
                id="menu-appbar"
                anchorEl={anchorElUser}
                anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
                keepMounted
                transformOrigin={{ vertical: 'top', horizontal: 'right' }}
                open={Boolean(anchorElUser)}
                onClose={handleCloseUserMenu}
              >
                 {user?.fullName && (
                    <MenuItem disabled sx={{ '&.Mui-disabled': { opacity: 1, fontWeight: 'medium'} }}>
                        <Typography textAlign="center">{user.fullName}</Typography>
                    </MenuItem>
                 )}
                 <MenuItem onClick={() => handleNavigate(dashboardPath)}>
                    <DashboardIcon fontSize="small" sx={{mr: 1}}/> Bảng điều khiển
                 </MenuItem>
                 {/* Các menu item khác như cũ (Hồ sơ, Cài đặt, Đăng xuất) */}
                 <MenuItem onClick={() => handleNavigate(profilePath)}>
                    <AccountCircle fontSize="small" sx={{mr: 1}}/> Hồ sơ
                 </MenuItem>
                 <MenuItem onClick={() => handleNavigate(settingsPath)}>
                    <SettingsIcon fontSize="small" sx={{mr: 1}}/> Cài đặt
                 </MenuItem>
                 <MenuItem onClick={handleLogout}>
                    <LogoutIcon fontSize="small" sx={{mr: 1}}/> Đăng xuất
                 </MenuItem>
              </Menu>
            </>
          ) : (
            <>
              {/* Login/Register Buttons như cũ */}
              <Button color="inherit" component={RouterLink} to="/login">
                Đăng nhập
              </Button>
              <Button variant="contained" color="primary" component={RouterLink} to="/register">
                Đăng ký
              </Button>
            </>
          )}
        </Box>
      </Toolbar>
    </AppBar>
  );
}

export default Header;
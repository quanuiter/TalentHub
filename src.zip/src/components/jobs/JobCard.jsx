// src/components/jobs/JobCard.jsx
import React from 'react';
import { Link as RouterLink } from 'react-router-dom';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardActions from '@mui/material/CardActions';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import AttachMoneyIcon from '@mui/icons-material/AttachMoney';
import PropTypes from 'prop-types';
import EventIcon from '@mui/icons-material/Event'; // Thêm icon ngày đăng nếu muốn

function JobCard({ job, showSaveButton = true, onUnsave }) {
  if (!job) return null;

  return (
    // === THAY ĐỔI Ở ĐÂY ===
    // Thêm display: 'flex', flexDirection: 'column' 
    <Card sx={{ height: '100%', width: '16.1em', display: 'flex', flexDirection: 'column', mb: 2 }}>
      {/* Phần nội dung chính */}
      {/* Thêm flexGrow: 1 để nó chiếm không gian */}
      <CardContent sx={{ flexGrow: 1 }}>
        {/* Có thể đặt minHeight cho Title nếu muốn đảm bảo ít nhất 2 dòng */}
        <Typography
            gutterBottom
            variant="h6"
            component="div"
            sx={{
                '& a': { textDecoration: 'none', color: 'inherit' },
                // TÙY CHỌN: Giới hạn số dòng và thêm dấu ... nếu quá dài
                maxHeight: '3.2em', // Giới hạn chiều cao tối đa cho 2 dòng
                maxWidth: '100%', // Giới hạn chiều rộng tối đa
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                display: '-webkit-box',
                WebkitLineClamp: '2', // Giới hạn 2 dòng
                WebkitBoxOrient: 'vertical',
                minHeight: '3.2em' // Đảm bảo chiều cao tối thiểu cho 2 dòng (điều chỉnh nếu cần)
            }}
        >
          <RouterLink to={`/jobs/${job.id}`}>{job.title}</RouterLink>
        </Typography>
        <Typography variant="subtitle1" color="text.secondary" gutterBottom sx={{ minHeight: '2em' /* Giữ chỗ tên cty */ }}>
          {job.companyName}
        </Typography>
        {/* Các thông tin khác */}
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 0.5, color: 'text.secondary', minHeight: '1.5em' }}>
          <LocationOnIcon sx={{ mr: 0.5, fontSize: '1rem' }} />
          <Typography variant="body2" noWrap> {/* noWrap để tránh tràn nếu địa chỉ quá dài */}
            {job.location}
          </Typography>
        </Box>
         <Box sx={{ display: 'flex', alignItems: 'center', mb: 0.5, color: 'text.secondary', minHeight: '1.5em' }}>
          <AttachMoneyIcon sx={{ mr: 0.5, fontSize: '1rem' }} />
          <Typography variant="body2" noWrap>
            {job.salary || 'Thương lượng'}
          </Typography>
        </Box>
         <Typography variant="body2" color="text.secondary" sx={{ mb: 1, minHeight: '1.5em' }}>
           Loại hình: {job.type}
        </Typography>
         {/* Tùy chọn: Thêm ngày đăng */}
         <Box sx={{ display: 'flex', alignItems: 'center', color: 'text.disabled', mt: 1 }}>
             <EventIcon sx={{ mr: 0.5, fontSize: '0.875rem' }} />
             <Typography variant="caption">
                 Đăng ngày: {new Date(job.datePosted).toLocaleDateString('vi-VN')}
             </Typography>
         </Box>
      </CardContent>

      {/* Phần Actions - Sẽ tự động bị đẩy xuống dưới cùng */}
      {/* Bỏ mt: 'auto' nếu dùng flexGrow ở CardContent */}
      <CardActions sx={{ justifyContent: 'space-between', px: 2, pb: 2 /* mt: 'auto' */ }}>
         {/* Nút Lưu/Bỏ lưu */}
         {onUnsave ? (
             <Button size="small" variant="outlined" color="error" onClick={() => onUnsave(job.id)}>
                 Bỏ lưu
             </Button>
         ) : showSaveButton && (
             <Button size="small" variant="outlined">
                 Lưu tin
             </Button>
         )}
        <Button size="small" variant="contained" component={RouterLink} to={`/jobs/${job.id}`}>
          Xem chi tiết
        </Button>
      </CardActions>
    </Card>
  );
}

JobCard.propTypes = {
  job: PropTypes.object.isRequired,
  showSaveButton: PropTypes.bool,
  onUnsave: PropTypes.func,
};

export default JobCard;
import React from 'react';
import AppRouter from './routes/AppRouter';

function App() {
  // Có thể thêm logic context provider ở đây sau
  return <AppRouter />;
}

export default App;
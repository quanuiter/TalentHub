// src/pages/JobListingsPage.jsx
import React, { useState, useEffect, useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router-dom'; // Import useLocation/useNavigate để đọc/ghi query params
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Paper from '@mui/material/Paper';
import TextField from '@mui/material/TextField';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import Button from '@mui/material/Button';
import JobCard from '../components/jobs/JobCard'; //
import { fetchJobs } from '../data/mockJobs'; //
import LoadingSpinner from '../components/ui/LoadingSpinner'; //
import Pagination from '@mui/material/Pagination';
import Divider from '@mui/material/Divider';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import Slider from '@mui/material/Slider';
import Stack from '@mui/material/Stack'; // Dùng Stack cho nút filter
import InputAdornment from '@mui/material/InputAdornment';
import IconButton from '@mui/material/IconButton';
import Container from '@mui/material/Container';

// Icons
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import FilterListIcon from '@mui/icons-material/FilterList';
import SearchIcon from '@mui/icons-material/Search';
import ClearAllIcon from '@mui/icons-material/ClearAll';
import FindInPageOutlinedIcon from '@mui/icons-material/FindInPageOutlined'; // Icon cho trạng thái rỗng

// Mock data for filters (Lấy từ file khác hoặc định nghĩa ở đây)
const mockJobTypes = ['Full-time', 'Part-time', 'Hợp đồng', 'Thực tập', 'Remote'];
const mockLocations = ['TP. Hồ Chí Minh', 'Hà Nội', 'Đà Nẵng', 'Remote', 'Khác'];
const mockExperiences = ['Chưa có kinh nghiệm', 'Dưới 1 năm', '1 năm', '2 năm', '3 năm', '4 năm', '5 năm', 'Trên 5 năm'];
const mockSalaryRanges = [
    { value: '0-10', label: 'Dưới 10 triệu' },
    { value: '10-15', label: '10 - 15 triệu' },
    { value: '15-20', label: '15 - 20 triệu' },
    { value: '20-30', label: '20 - 30 triệu' },
    { value: '30-50', label: '30 - 50 triệu' },
    { value: '50+', label: 'Trên 50 triệu' },
    { value: 'thoathuan', label: 'Thương lượng' },
];

// Helper để phân tích query params từ URL
function useQuery() {
  return new URLSearchParams(useLocation().search);
}

// --- Component Chính ---
function JobListingsPage() {
  const navigate = useNavigate();
  const query = useQuery(); // Đọc query params ban đầu

  const [allJobs, setAllJobs] = useState([]); // Lưu tất cả jobs gốc
  const [filteredJobs, setFilteredJobs] = useState([]); // Jobs sau khi lọc
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // State cho bộ lọc
  const [filters, setFilters] = useState({
    keyword: query.get('keyword') || '', // Lấy từ URL nếu có
    locations: query.getAll('location') || [], // Lấy từ URL nếu có (dạng mảng)
    jobTypes: [],
    experienceLevels: query.getAll('experience') || [], // <<< THÊM DÒNG NÀY
    salaryRanges: query.getAll('salary') || [], // <<< THÊM DÒNG NÀY// Hoặc một giá trị mặc định [min, max]
    // Thêm các bộ lọc khác nếu cần: industry, skills...
  });

  // State cho sắp xếp và phân trang
  const [sortBy, setSortBy] = useState('newest'); // 'newest', 'relevance' (relevance cần backend)
  const [currentPage, setCurrentPage] = useState(1);
  const jobsPerPage = 9; // Số job mỗi trang (tăng lên 9 cho layout 3 cột)

  // Callback để cập nhật Query Params trên URL
  const updateQueryParams = useCallback((newFilters) => {
    const params = new URLSearchParams();
    if (newFilters.keyword) params.set('keyword', newFilters.keyword);
    newFilters.locations.forEach(loc => params.append('location', loc));
    newFilters.jobTypes.forEach(type => params.append('jobType', type));
    newFilters.experienceLevels.forEach(exp => params.append('experience', exp)); // <<< THÊM DÒNG NÀY
    newFilters.salaryRanges.forEach(sal => params.append('salary', sal)); // <<< THÊM DÒNG NÀY
    // Thêm các filter khác vào params...
    navigate(`?${params.toString()}`, { replace: true }); // replace: true để không tạo history mới cho mỗi lần lọc
  }, [navigate]);


  // Load tất cả jobs lần đầu
  useEffect(() => {
    const loadAllJobs = async () => {
      setLoading(true);
      setError(null);
      try {
        const fetchedJobs = await fetchJobs(); //
        setAllJobs(fetchedJobs);
        // Áp dụng bộ lọc ban đầu (từ URL) ngay sau khi load xong
        applyFilters(fetchedJobs, filters);
      } catch (err) {
        console.error("Lỗi tải jobs:", err);
        setError("Không thể tải danh sách việc làm.");
      } finally {
        setLoading(false);
      }
    };
    loadAllJobs();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // Chỉ chạy 1 lần khi mount

  // Hàm áp dụng bộ lọc (có thể gọi từ useEffect hoặc nút Apply)
  const applyFilters = (jobsToFilter, currentFilters) => {
      console.log("Applying filters:", currentFilters);
      const filtered = jobsToFilter.filter(job => {
          const keywordMatch = !currentFilters.keyword ||
                               job.title.toLowerCase().includes(currentFilters.keyword.toLowerCase()) ||
                               job.companyName.toLowerCase().includes(currentFilters.keyword.toLowerCase());

          const locationMatch = currentFilters.locations.length === 0 ||
                                currentFilters.locations.includes(job.location) ||
                                (currentFilters.locations.includes('Khác') && !mockLocations.slice(0, -1).includes(job.location)); // Logic cho 'Khác'

          const typeMatch = currentFilters.jobTypes.length === 0 ||
                            currentFilters.jobTypes.includes(job.type);

                    // --- THÊM LOGIC LỌC KINH NGHIỆM ---
                  // Giả sử job.experienceLevel là một string khớp với giá trị trong mockExperiences
                  const experienceMatch = currentFilters.experienceLevels.length === 0 ||
                  (job.experienceLevel && currentFilters.experienceLevels.includes(job.experienceLevel));

                    // --- THÊM LOGIC LỌC MỨC LƯƠNG (Phức tạp hơn) ---
                    // Cần hàm helper để kiểm tra job.salary có nằm trong các khoảng đã chọn không
                    // Ví dụ đơn giản: Chỉ kiểm tra nếu chọn 'Thương lượng'
                    // Hoặc nếu job.salaryCategory khớp với value ('10-15', '15-20',...)
                  const salaryMatch = currentFilters.salaryRanges.length === 0 ||
                  (currentFilters.salaryRanges.includes('thoathuan') && (job.salary || '').toLowerCase() === 'thương lượng') ||
                // Thêm logic kiểm tra khoảng lương nếu job.salary là số hoặc có category
                checkSalaryRange(job.salary, currentFilters.salaryRanges); // <<< Cần tạo hàm checkSalaryRange

          // --- Kết hợp tất cả điều kiện ---
          return keywordMatch && locationMatch && typeMatch && experienceMatch && salaryMatch;
      });

       // Sắp xếp (ví dụ đơn giản theo ngày đăng)
      if (sortBy === 'newest') {
          filtered.sort((a, b) => new Date(b.datePosted) - new Date(a.datePosted));
      } // Thêm logic sort khác nếu cần

      setFilteredJobs(filtered);
      setCurrentPage(1); // Reset về trang 1 sau khi lọc/sắp xếp
      console.log("Filtered result count:", filtered.length);
  };
  const checkSalaryRange = (jobSalary, selectedRanges) => {
    // Nếu không chọn range nào thì coi như khớp
    if (selectedRanges.length === 0) return true;
    // Nếu chọn 'Thương lượng' và lương job là 'Thương lượng'
    if (selectedRanges.includes('thoathuan') && (jobSalary || '').toLowerCase() === 'thương lượng') {
        return true;
    }

    // Xử lý các khoảng số (phức tạp, cần phân tích jobSalary và các range)
    // Ví dụ rất đơn giản: Giả sử job có job.salaryCategory = '10-15'
    // return selectedRanges.includes(job.salaryCategory);

    // Logic đầy đủ cần xử lý số, đơn vị tiền tệ, các khoảng "dưới", "trên"
    // Tạm thời trả về false nếu không phải là trường hợp thương lượng ở trên
    console.warn("Logic checkSalaryRange chưa được triển khai đầy đủ!");
    return false; // <<< Tạm thời return false cho các khoảng khác
};
  // --- Handlers cho Bộ lọc ---
  const handleFilterChange = (event) => {
    const { name, value } = event.target;
    setFilters(prevFilters => ({
      ...prevFilters,
      [name]: value,
    }));
  };

  const handleCheckboxChange = (event) => {
    const { name, value, checked } = event.target; // name là group (locations, jobTypes), value là giá trị checkbox
    setFilters(prevFilters => ({
        ...prevFilters,
        [name]: checked
            ? [...prevFilters[name], value] // Add value if checked
            : prevFilters[name].filter(item => item !== value) // Remove value if unchecked
    }));
  };

  // Handler cho nút "Áp dụng bộ lọc"
  const handleApplyFiltersClick = () => {
      applyFilters(allJobs, filters);
      updateQueryParams(filters); // Cập nhật URL khi bấm áp dụng
  };

  // Handler cho nút "Xóa bộ lọc"
  const handleClearFilters = () => {
      const clearedFilters = {
        keyword: '', locations: [], jobTypes: [], experienceLevels: [], salaryRange: [],
      };
      setFilters(clearedFilters);
      applyFilters(allJobs, clearedFilters); // Áp dụng lại với filter trống
      updateQueryParams(clearedFilters); // Cập nhật URL
  };

  // Handler cho thay đổi trang
  const handlePageChange = (event, value) => {
    setCurrentPage(value);
     window.scrollTo(0, 0); // Cuộn lên đầu trang khi đổi trang
  };

  // Handler cho thay đổi sắp xếp
   const handleSortChange = (event) => {
        const newSortBy = event.target.value;
        setSortBy(newSortBy);
        // Áp dụng lại filter và sort với danh sách gốc
        // Lưu ý: Cần gọi applyFilters vì nó chứa cả logic sort
        applyFilters(allJobs, filters);
    };

   // Tính toán jobs cho trang hiện tại
  const indexOfLastJob = currentPage * jobsPerPage;
  const indexOfFirstJob = indexOfLastJob - jobsPerPage;
  const currentJobs = filteredJobs.slice(indexOfFirstJob, indexOfLastJob);
  const pageCount = Math.ceil(filteredJobs.length / jobsPerPage);
  console.log(mockLocations);
  console.log(mockJobTypes)
  console.log('Kiểm tra filters state:', filters);
  // --- Render ---
  return (
    <Container maxWidth="lg" sx={{ mt: 3 }}>
        <Grid container spacing={3} alignItems="flex-start">
        {/* === Filters Sidebar (Cột Trái) === */}
        <Grid item xs={12} md={3}>
            <Paper sx={{ p: 2, position: 'sticky', top: 80 }}> {/* Sticky sidebar */}
            <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center' }}>
                <FilterListIcon sx={{ mr: 1 }}/> Bộ lọc
            </Typography>
            <Divider sx={{ mb: 2 }} />

            {/* Nút Áp dụng / Xóa */}
            <Stack direction="column" spacing={1} sx={{ mb: 2 }}>
                <Button
                    variant="contained"
                    fullWidth
                    onClick={handleApplyFiltersClick}
                    startIcon={<SearchIcon />}
                >
                    Áp dụng
                </Button>
                 <Button
                    variant="outlined"
                    fullWidth
                    onClick={handleClearFilters}
                    startIcon={<ClearAllIcon />}
                    size="small"
                 >
                    Xóa bộ lọc
                </Button>
            </Stack>

            {/* Bộ lọc Keyword */}
            <TextField
                fullWidth
                label="Từ khóa"
                name="keyword"
                value={filters.keyword}
                onChange={handleFilterChange}
                size="small"
                sx={{ mb: 2 }}
                InputProps={{
                    endAdornment: (
                    <InputAdornment position="end">
                        <SearchIcon color="action"/>
                    </InputAdornment>
                    ),
                }}
            />
             <Divider sx={{ mb: 2 }} />

            {/* Các bộ lọc trong Accordion */}
            {/* Mở sẵn Địa điểm */}

                <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                    <Typography variant="subtitle1">Địa điểm</Typography>
                </AccordionSummary>
                <AccordionDetails sx={{ maxHeight: 200, overflowY: 'auto', p: 1 }}>
                    <FormGroup>
                        {mockLocations.map(location => (
                            <FormControlLabel
                                key={location}
                                control={
                                    <Checkbox
                                        checked={filters.locations.includes(location)}
                                        onChange={handleCheckboxChange}
                                        name="locations" // Group name
                                        value={location}
                                        size="small"
                                    />
                                }
                                label={location}
                                sx={{ mb: -0.5 }} // Giảm khoảng cách dọc
                             />
                        ))}
                    </FormGroup>
                </AccordionDetails>
           

            <Accordion>
                <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                    <Typography variant="subtitle1">Loại hình công việc</Typography>
                </AccordionSummary>
                 <AccordionDetails sx={{ p: 1 }}>
                    <FormGroup>
                         {mockJobTypes.map(type => (
                            <FormControlLabel
                                key={type}
                                control={
                                    <Checkbox
                                        checked={filters.jobTypes.includes(type)}
                                        onChange={handleCheckboxChange}
                                        name="jobTypes" // Group name
                                        value={type}
                                        size="small"
                                    />
                                }
                                label={type}
                                sx={{ mb: -0.5 }}
                             />
                        ))}
                    </FormGroup>
                </AccordionDetails>
            </Accordion>

            {/* Accordion Kinh nghiệm */}
              <Accordion>
                  <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                      <Typography variant="subtitle1">Kinh nghiệm</Typography>
                  </AccordionSummary>
                  <AccordionDetails sx={{ p: 1 }}> {/* Thêm lại sx nếu cần */}
                      <FormGroup>
                          {mockExperiences.map(exp => ( // Lặp qua mảng mockExperiences
                              <FormControlLabel
                                  key={exp}
                                  control={
                                      <Checkbox
                                          // Kiểm tra xem exp có trong mảng filters.experienceLevels không
                                          checked={filters.experienceLevels.includes(exp)}
                                          onChange={handleCheckboxChange}
                                          name="experienceLevels" // Group name phải khớp với state
                                          value={exp}
                                          size="small"
                                      />
                                  }
                                  label={exp}
                                  sx={{ mb: -0.5 }}
                              />
                          ))}
                      </FormGroup>
                  </AccordionDetails>
              </Accordion>

             {/* Accordion Mức lương */}
              <Accordion>
                  <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                      <Typography variant="subtitle1">Mức lương</Typography>
                  </AccordionSummary>
                  <AccordionDetails sx={{ p: 1 }}>
                      <FormGroup>
                          {mockSalaryRanges.map(range => ( // Lặp qua mảng mockSalaryRanges
                              <FormControlLabel
                                  key={range.value} // Dùng value làm key
                                  control={
                                      <Checkbox
                                          // Kiểm tra xem range.value có trong mảng filters.salaryRanges không
                                          checked={filters.salaryRanges.includes(range.value)}
                                          onChange={handleCheckboxChange}
                                          name="salaryRanges" // Group name phải khớp với state
                                          value={range.value} // Lưu value (ví dụ: '10-15') vào state
                                          size="small"
                                      />
                                  }
                                  label={range.label} // Hiển thị label (ví dụ: '10 - 15 triệu')
                                  sx={{ mb: -0.5 }}
                              />
                          ))}
                      </FormGroup>
                  </AccordionDetails>
              </Accordion>

            {/* Thêm các Accordion khác cho Ngành nghề, etc. */}

            </Paper>
        </Grid>

        {/* === Job Listings Area (Cột Phải) === */}
        <Grid item xs={12} md={9} sx={{ width: '70%'}}>
             {/* Header của kết quả: Số lượng & Sắp xếp */}
            <Paper sx={{ width:'100%' , flexShrink: 0, p: 1.5, mb: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#f8f9fa' }}>
                <Typography variant="subtitle1" fontWeight="medium">
                    Tìm thấy {loading ? '...' : filteredJobs.length} việc làm
                </Typography>
                <FormControl size="small" variant="outlined" sx={{ minWidth: 150 }}>
                    <InputLabel>Sắp xếp</InputLabel>
                    <Select value={sortBy} label="Sắp xếp" onChange={handleSortChange}>
                    <MenuItem value="newest">Mới nhất</MenuItem>
                    {/* <MenuItem value="relevance" disabled>Liên quan nhất</MenuItem> */}
                    {/* Thêm các lựa chọn sort khác */}
                    </Select>
                </FormControl>
            </Paper>

            {/* Hiển thị Loading, Lỗi hoặc Kết quả */}
            {loading ? (
            <LoadingSpinner /> //
            ) : error ? (
                 <Alert severity="error" sx={{ mt: 2 }}>{error}</Alert>
            ) : (
            <Box>
                <Grid container spacing={2}>
                {currentJobs.length > 0 ? (
                    currentJobs.map((job) => (
                    <Grid item xs={12} sm={6} lg={4} key={job.id}> {/* 3 cột trên lg */}
                        <JobCard job={job} />
                    </Grid>
                    ))
                ) : (
                    // Trạng thái không tìm thấy việc làm
                    <Grid item xs={12} sx={{ width: '100%',textAlign: 'center', mt: 4 }}>
                         <FindInPageOutlinedIcon sx={{ fontSize: 60, color: 'text.secondary', mb: 2 }}/>
                        <Typography variant="h6" gutterBottom>Không tìm thấy việc làm phù hợp</Typography>
                        <Typography color="text.secondary">
                            Vui lòng thử thay đổi hoặc xóa bớt bộ lọc để có kết quả tốt hơn.
                        </Typography>
                    </Grid>
                )}
                </Grid>

                {/* Phân trang */}
                {pageCount > 1 && (
                    <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4, mb: 2 }}>
                        <Pagination
                            count={pageCount}
                            page={currentPage}
                            onChange={handlePageChange}
                            color="primary"
                            showFirstButton showLastButton // Hiện nút đầu/cuối
                        />
                    </Box>
                )}
            </Box>
            )}
        </Grid>
        </Grid>
    </Container>
  );
}

export default JobListingsPage;
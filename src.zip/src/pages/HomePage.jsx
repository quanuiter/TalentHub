// src/pages/HomePage.jsx
import React, { useState, useEffect } from 'react';
import { Link as RouterLink, useNavigate } from 'react-router-dom'; // Thêm useNavigate
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Autocomplete from '@mui/material/Autocomplete'; // Dùng cho địa điểm
import Paper from '@mui/material/Paper';
import Chip from '@mui/material/Chip';
import Container from '@mui/material/Container'; // Dùng Container để căn giữa tốt hơn

import JobCard from '../components/jobs/JobCard'; //
import CompanyCard from '../components/companies/companyCard'; //
import { fetchJobs } from '../data/mockJobs'; //
import { fetchCompanies, mockCompanies } from '../data/mockCompanies'; //
import LoadingSpinner from '../components/ui/LoadingSpinner'; //

// Dữ liệu giả lập cho bộ lọc nhanh (lấy từ mock hoặc định nghĩa riêng)
const popularCategories = [
    { label: 'CNTT - Phần mềm', value: 'it-software' },
    { label: 'Marketing', value: 'marketing' },
    { label: 'Bán hàng', value: 'sales' },
    { label: 'Thiết kế', value: 'design' },
    { label: 'Nhân sự', value: 'hr' },
];
const popularLocations = ['TP. Hồ Chí Minh', 'Hà Nội', 'Đà Nẵng', 'Remote']; // Lấy từ mockJobs hoặc định nghĩa

function HomePage() {
  const navigate = useNavigate(); // Hook để điều hướng
  const [featuredJobs, setFeaturedJobs] = useState([]);
  const [featuredCompanies, setFeaturedCompanies] = useState([]);
  const [loadingJobs, setLoadingJobs] = useState(true);
  const [loadingCompanies, setLoadingCompanies] = useState(true);

  // State cho thanh tìm kiếm
  const [searchKeyword, setSearchKeyword] = useState('');
  const [searchLocation, setSearchLocation] = useState(null); // Dùng null cho Autocomplete

  // Load jobs và companies
  useEffect(() => {
    const loadData = async () => {
      setLoadingJobs(true);
      setLoadingCompanies(true);
      try {
        const [jobsData, companiesData] = await Promise.all([
          fetchJobs(), //
          fetchCompanies() //
        ]);
        // Lấy 6 job mới nhất (hoặc nổi bật)
        setFeaturedJobs(jobsData.slice(0, 6));
        // Lấy 6 công ty nổi bật
        setFeaturedCompanies(companiesData.slice(0, 6));
      } catch (error) {
        console.error("Lỗi tải dữ liệu trang chủ:", error);
        // Có thể set state lỗi ở đây nếu muốn
      } finally {
        setLoadingJobs(false);
        setLoadingCompanies(false);
      }
    };
    loadData();
  }, []);

  // Xử lý tìm kiếm
  const handleSearch = (event) => {
    event.preventDefault();
    const keywordQuery = searchKeyword ? `keyword=${encodeURIComponent(searchKeyword)}` : '';
    const locationQuery = searchLocation ? `location=${encodeURIComponent(searchLocation)}` : '';
    const queryParams = [keywordQuery, locationQuery].filter(Boolean).join('&');
    console.log('Navigating to:', `/jobs?${queryParams}`);
    navigate(`/jobs?${queryParams}`); // Điều hướng đến trang jobs với query params
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 2, mb: 4 }}> {/* Dùng Container bao ngoài */}
      {/* === Hero Section === */}
      <Paper
        elevation={0} // Bỏ shadow nếu muốn nền hòa vào trang
        sx={{
          p: { xs: 3, md: 6 }, // Padding responsive
          mb: 4, // Margin bottom
          textAlign: 'center',
          backgroundColor: 'primary.main', // Màu nền chính
          color: 'primary.contrastText', // Màu chữ tương phản
          borderRadius: 2, // Bo góc nhẹ
        }}
      >
        <Typography variant="h3" component="h1" fontWeight="bold" gutterBottom>
          Kết Nối Tài Năng - Kiến Tạo Tương Lai
        </Typography>
        <Typography variant="h6" component="p" sx={{ mb: 4, opacity: 0.9 }}>
          Khám phá hàng ngàn cơ hội việc làm từ các công ty hàng đầu tại Việt Nam.
        </Typography>
        <Box
            component="form"
            onSubmit={handleSearch}
            sx={{
                display: 'flex',
                flexDirection: { xs: 'column', sm: 'row' }, // Xếp dọc trên mobile, ngang trên màn lớn hơn
                justifyContent: 'center',
                alignItems: 'center',
                gap: 1.5, // Khoảng cách giữa các input
                p: 2,
                backgroundColor: 'rgba(255, 255, 255, 0.1)', // Nền nhẹ cho form search
                borderRadius: 1,
                maxWidth: '700px', // Giới hạn chiều rộng form search
                mx: 'auto' // Căn giữa form
            }}
        >
          <TextField
            variant="outlined"
            placeholder="Nhập chức danh, kỹ năng, công ty..."
            size="small"
            value={searchKeyword}
            onChange={(e) => setSearchKeyword(e.target.value)}
            sx={{
                backgroundColor: 'white',
                borderRadius: 1,
                flexGrow: 1, // Chiếm không gian còn lại
                minWidth: { xs: '100%', sm: '300px'} // Độ rộng tối thiểu
             }}
             InputProps={{ sx: { color: 'text.primary' } }} // Chữ màu đen
          />
          <Autocomplete
            options={popularLocations} // Lấy danh sách địa điểm từ mock data hoặc API sau này
            value={searchLocation}
            onChange={(event, newValue) => {
                setSearchLocation(newValue);
            }}
            freeSolo // Cho phép nhập địa điểm tùy ý
            size="small"
            sx={{
                backgroundColor: 'white',
                borderRadius: 1,
                width: { xs: '100%', sm: '200px' } // Độ rộng cố định hoặc responsive
            }}
            renderInput={(params) => (
                <TextField
                    {...params}
                    placeholder="Địa điểm"
                    variant="outlined"
                    InputProps={{ ...params.InputProps, sx: { color: 'text.primary' } }} // Chữ màu đen
                 />
            )}
            />
          <Button variant="contained" color="secondary" type="submit" sx={{ width: { xs: '100%', sm: 'auto' }, px: 3, py: 1 }}>
            Tìm kiếm
          </Button>
        </Box>
      </Paper>

      {/* === Quick Browse by Category === */}
      <Box sx={{ my: 4, textAlign: 'center' }}>
        <Typography variant="h5" component="h2" gutterBottom>
          Tìm việc theo ngành nghề
        </Typography>
        <Box sx={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: 1 }}>
          {popularCategories.map((category) => (
            <Chip
              key={category.value}
              label={category.label}
              onClick={() => navigate(`/jobs?category=${category.value}`)} // Điều hướng khi click
              clickable
              variant="outlined" // Kiểu viền ngoài
              color="primary"
            />
          ))}
           <Chip
              label="Xem tất cả"
              onClick={() => navigate(`/jobs`)} // Điều hướng đến trang jobs
              clickable
              color="primary" // Màu khác biệt
            />
        </Box>
      </Box>

      {/* === Featured Jobs Section === */}
      <Typography variant="h5" component="h2" gutterBottom sx={{ mt: 5, mb: 2 }}>
        Việc làm mới nhất
      </Typography>
      {loadingJobs ? (
        <LoadingSpinner /> //
      ) : (
        <Grid container spacing={2}>
          {featuredJobs.length > 0 ? (
            featuredJobs.map((job) => (
              <Grid item xs={12} sm={6} md={4} key={job.id}>
                <JobCard job={job} />
              </Grid>
            ))
          ) : (
            <Grid item xs={12}>
                <Typography sx={{ ml: 1, fontStyle: 'italic', color: 'text.secondary' }}>
                    Hiện chưa có việc làm nào.
                </Typography>
            </Grid>
          )}
        </Grid>
      )}
      <Box sx={{ textAlign: 'center', my: 3 }}>
        <Button variant="outlined" component={RouterLink} to="/jobs">
          Xem tất cả việc làm
        </Button>
      </Box>

       {/* === Employer CTA Section === */}
       <Paper elevation={2} sx={{ p: 4, my: 5, backgroundColor: 'secondary.light', color: 'secondary.contrastText', textAlign: 'center', borderRadius: 2 }}>
            <Typography variant="h5" fontWeight="medium" gutterBottom>
                Dành cho Nhà tuyển dụng
            </Typography>
            <Typography sx={{ mb: 3 }}>
                Đăng tin tuyển dụng và tiếp cận hàng ngàn ứng viên tiềm năng một cách nhanh chóng và hiệu quả.
            </Typography>
            <Button variant="contained" color="warning" component={RouterLink} to="/employer/post-job">
                Đăng tin ngay
            </Button>
       </Paper>

      {/* === Featured Companies Section === */}
      <Typography variant="h5" component="h2" gutterBottom sx={{ mt: 5, mb: 2 }}>
        Công ty hàng đầu
      </Typography>
      {loadingCompanies ? (
        <LoadingSpinner /> //
      ) : (
        <Grid container spacing={2}>
          {featuredCompanies.length > 0 ? (
            featuredCompanies.map((company) => (
              <Grid item xs={12} sm={6} md={4} lg={2} key={company.id}> {/* Thu nhỏ cột cho company */}
                <CompanyCard company={company} />
              </Grid>
            ))
           ) : (
             <Grid item xs={12}>
                <Typography sx={{ ml: 1, fontStyle: 'italic', color: 'text.secondary' }}>
                    Hiện chưa có thông tin công ty.
                </Typography>
            </Grid>
          )}
        </Grid>
      )}
      <Box sx={{ textAlign: 'center', my: 3 }}>
        <Button variant="outlined" component={RouterLink} to="/companies"> {/* Giả sử có trang /companies */}
          Xem tất cả công ty
        </Button>
      </Box>

    </Container> // Đóng Container
  );
}

export default HomePage;